from wpipe.util.utils import leer_yaml
from wpipe.exception import TaskError, ProcessError, ApiError
from wkafka.controller import Wkafka

from microservice import Microservice

from steps import funcion_1, funcion_2, funcion_3, Demo

config_file = "config.yaml"
CONFIG = leer_yaml(config_file)

# Iniciar Kafka
kafka_instance = Wkafka(server=CONFIG["kafka_server"], name=CONFIG["name"])
microservice = Microservice(kafka_instance, config_file=config_file)


microservice.set_steps(
    [
        (funcion_1, "Primera_Funcion", "v1.0"),
        (funcion_2, "Segunda_Funcion", "v1.0"),
        (funcion_3, "Tercera_funcion", "v1.0"),
        (Demo(), "Cuarta_funcion", "v1.0"),
    ]
)

microservice.start_healthchecker()


try:
    final_result = microservice.run(
        {
            "queso": 5,
            #"x": 3,
        }
    )
    print(final_result)
except TaskError as te:
    print(te)
except ProcessError as e:
    print(e)
except ApiError as ae:
    print(ae)
except Exception as e:
    print(e)


microservice.wait()
